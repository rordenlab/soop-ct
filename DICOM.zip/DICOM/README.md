## About

This folder contains DICOM datasets from three individuals. The goal is to demonstrate how DICOM CT scans can be converted into BIDS-format repositories using the included scripts. Because our center does not permit distribution of raw DICOM images, these samples are sourced from the [Acute Ischemic Infarct Segmentation](https://github.com/GriffinLiang/AISD) dataset and are shared under its license.

## License

This dataset is made freely available to academic and non-academic entities for non-commercial purposes such as academic research, teaching, scientific publications, or personal experimentation.

## Citation

Liang K, Han K, Li X, Cheng X, Li Y, Wang Y, Yu Y (2021) Symmetry-enhanced attention network for acute ischemic infarct segmentation with non-contrast CT images. in Medical Image Computing and Computer Assisted Intervention – MICCAI 2021 432–441 (Springer International Publishing, Cham, 2021, ISBN: 9783030872335).